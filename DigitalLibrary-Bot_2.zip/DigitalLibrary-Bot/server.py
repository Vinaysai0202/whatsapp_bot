import requests
from fastapi import FastAPI, Request
from shared.request_format import WhatsAppResponse
from app.whatsapp import WHATSAPP
from shared.api_handler import APIHANDLER
import logging
import os
from shared.logger import setup_logging
setup_logging()
logger = logging.getLogger('WHATSAPP_BOT')

app = FastAPI()
user_data = {} 

@app.post("/send_message")
async def send_whatsapp_message(whatsapp_message: WhatsAppResponse):
    logger.info("Send a WhatsApp message using the WhatsApp Business API.")
    api_connection = APIHANDLER()
    response = await api_connection.send_whatsapp_message(recipient_waid=whatsapp_message.recipient_waid, message=whatsapp_message.message)
    return response
    
@app.get("/webhook")
async def verify_webhook(request: Request):
    logger.info("WhatsApp will send a GET request to verify the webhook. verify_token")
    verify_token = request.query_params.get('hub.verify_token')
    challenge = request.query_params.get('hub.challenge')

    if verify_token == os.getenv("VERIFY_TOKEN"):
        return int(challenge)
    else:
        return {"status": "Verification token mismatch"}

@app.post("/webhook")
async def receive_webhook(request: Request):
    """
    Webhook to receive incoming WhatsApp messages and handle user state.
    """
    logger.info("Webhook to receive incoming WhatsApp messages and handle user state.")
    data = await request.json()
    whatsapp = WHATSAPP()
    await whatsapp.whatsapp_bot(data=data)
    
    return {"status": "Webhook processed successfully."}