import requests
from typing import Dict, Any
import logging
import tempfile
import os
import threading
import time
import os
from shared.api_handler import APIHANDLER
# Global variable to hold the timer thread
exit_button_timer = None
timer_lock = threading.Lock()  # Lock to manage thread access to the timer
logger = logging.getLogger()

exit_button_timers = {}
timer_lock = threading.Lock()

user_states: Dict[str, Dict[str, Any]] = {}
uploaded_documents: Dict[str, bytes] = {}


class BUTTONS:
    def __init__(self):
        self.api_connection = APIHANDLER()
        self.container_mapping = {
                "print_media": ("print-media", "*Access to Digital Library Resource*"),  # Access to print media resources
                "digital_library": ("digital-library", "*Access to Digital Library Resource*"),  # Access to digital library materials
                "social_media": ("social-media", "*Engage with Social Media*"),  # Engage with social media content
                "district_news": ("news", "*Local News Articles*"),  # Local news and updates
                "government_orders": ("gos-library", "*Government Orders Resource*"),  # Government orders and regulations
                "file_upload": ("file-upload", "*Upload and Explore a File*"),  # Upload and manage files
                "global": ("global", "*Access to Global Resource*")  # Access to global resources
            }
        self.ACCESS_TOKEN = os.getenv('ACCESS_TOKEN')
        self.PHONE_NUMBER_ID = os.getenv('PHONE_NUMBER_ID')
        self.VERSION = os.getenv
        self.VERIFY_TOKEN = os.getenv("VERIFY_TOKEN") 
        self.EXTERNAL_API_URL = os.getenv('EXTERNAL_API_URL')
        self.QUERY_API_URL = os.getenv('QUERY_API_URL')

    async def send_list_message(self,sender_id:str,VERSION:str, ACCESS_TOKEN:str, PHONE_NUMBER_ID:str):
        """
        Send the header, body text once, and then send buttons in batches of 3.
        """
        logger.info(f"Sending button messages to {sender_id}.")
        VERSION = "v21.0"
        url = f"https://graph.facebook.com/{VERSION}/{PHONE_NUMBER_ID}/messages"
        headers = {
            "Authorization": f"Bearer {ACCESS_TOKEN}",
            "Content-Type": "application/json",
        }

        # Define all the options as buttons (split into 3 buttons per batch)
        all_buttons = [
        {"id": "digital_library", "title": "Digital Library", "description": "Access various resources."},
        {"id": "government_orders", "title": "Government Orders", "description": "Government issued orders and guidelines."},
        {"id": "print_media", "title": "Print Media", "description": "News and information from print sources."},
        {"id": "district_news", "title": "District News", "description": "Latest updates from your district."},
        {"id": "social_media", "title": "Social Media Data", "description": "Follow us on social media for real-time updates and insights."},
        {"id": "file_upload", "title": "Explore a file", "description": "Upload your documents here."},
        {"id": "global", "title": "Global Access", "description": "Access a variety of information."}
    ]

        # Chunk the options into groups of 3 (since WhatsApp allows only 3 buttons at a time)
        chunks = [all_buttons[i:i + 3] for i in range(0, len(all_buttons), 3)]

        # First message with header and body text, including the first 3 buttons
        first_chunk = chunks[0]
        buttons = [
            {
                "type": "reply",
                "reply": {
                    "id": button["id"],
                    "title": button["title"]
                }
            } for button in first_chunk
        ]

        data = {
            "messaging_product": "whatsapp",
            "to": sender_id,
            "type": "interactive",
            "interactive": {
                "type": "button",
                "header": {
                    "type": "text",
                    "text": "I am ready to assist you!"
                },
                "body": {
                    "text": "Please *Select* an option from the list below.👇"
                },
                "action": {
                    "buttons": buttons
                }
            }
        }

        # Send the first message with header, body, and first set of buttons
        response = requests.post(url, headers=headers, json=data)
        logger.info("response",response.text)
        logger.info(f"Sending request to URL: {url}")
        logger.info(f"Request headers: {headers}")
        logger.info(f"Request data: {data}")
        if response.status_code != 200:
            logger.error(f"Failed to send the first button message: {response.text}")
        else:
            logger.info(f"First button message sent successfully to {sender_id}.")

        # Send the remaining button sets with the body parameter included
        for idx, chunk in enumerate(chunks[1:], start=1):
            buttons = [
                {
                    "type": "reply",
                    "reply": {
                        "id": button["id"],
                        "title": button["title"]
                    }
                } for button in chunk
            ]
            if idx == 1:
                body_text = "*Browse More Resources 🌐*"
            else:
                body_text = "*View More Services 🌐*"
            
            data = {
                "messaging_product": "whatsapp",
                "to": sender_id,
                "type": "interactive",
                "interactive": {
                    "type": "button",
                    "body": {
                        # Changing the body slightly to avoid repetition
                        "text": body_text
                    },
                    "action": {
                        "buttons": buttons
                    }
                }
            }

            # Send the current batch of 3 buttons
            response = requests.post(url, headers=headers, json=data)

            if response.status_code != 200:
                logger.error(f"Failed to send button message batch: {response.text}")
            else:
                logger.info(f"Button message batch sent successfully to {sender_id}.")


    async def handle_button_click(self, button_id: str, container_mapping: dict,sender_id:str):
        logger.info(f'button_id: {button_id}')
        logger.info(f'container_mapping: {container_mapping}')

        # Handle 'exit' button press
        if button_id == "exit":
            # No need to retrieve container_id and description from container_mapping
            
            logger.info(f"Exit option selected by {sender_id}.")
            await self.handle_exit(sender_id)
            return button_id, None, None, None

        # Check if the button is valid
        if button_id in container_mapping:
            container_id, description = container_mapping[button_id]
            user_states["sender_id"] = {"current_container": container_id}

            # If 'file_upload' is selected, initiate the file upload process
            if container_id == "file-upload":
                return button_id, container_id, description, "📤 Please *Upload* your file(.docx, .doc, .pdf)"
            
            return button_id, container_id, description, f"📋 You have *Selected* the {description}, Please go ahead and ask your question."

        # Handle invalid button selections
        return button_id, None, None, "Invalid button selection. Please try again."



    async def send_message_with_exit_button(self, recipient_waid, message):
        """
        Start or reset a timer to send an exit button after 10 seconds of inactivity.
        """
        # Define a function to execute after the timer ends
        def delayed_send():
            with timer_lock:
                timer = exit_button_timers.get(recipient_waid)
                if timer is None:
                    logging.info(f"Timer canceled, not sending exit button to {recipient_waid}.")
                    return

                # Sending exit button directly here
                url = f"https://graph.facebook.com/{self.VERSION}/{self.PHONE_NUMBER_ID}/messages"
                headers = {
                    "Authorization": f"Bearer {self.ACCESS_TOKEN}",
                    "Content-Type": "application/json",
                }
                
                data = {
                    "messaging_product": "whatsapp",
                    "to": recipient_waid,
                    "type": "interactive",
                    "interactive": {
                        "type": "button",
                        "body": {"text": message},
                        "action": {
                            "buttons": [
                                {
                                    "type": "reply",
                                    "reply": {"id": "exit", "title": "Exit"}
                                }
                            ]
                        }
                    }
                }

                response = requests.post(url, headers=headers, json=data)
                if response.status_code != 200:
                    logging.error(f"Failed to send exit button: {response.text}")
                else:
                    logging.info(f"Exit button sent successfully to {recipient_waid}.")

        # Cancel the previous timer if it exists for this recipient
        with timer_lock:
            if recipient_waid in exit_button_timers:
                exit_button_timers[recipient_waid].cancel()
                logging.info(f"Canceled previous exit button timer for {recipient_waid}.")
            
            # Start a new timer for this recipient
            exit_button_timers[recipient_waid] = threading.Timer(50, delayed_send)
            exit_button_timers[recipient_waid].start()
            logging.info(f"Started new exit button timer for {recipient_waid}.")

    async def handle_exit(self,sender_id: str):
        """
        Handles the exit command from the user and clears the uploaded document from memory.
        Sets the user as exited.
        """
        logger.info(f"Handling exit command for user: {sender_id}.")
        try:
            if sender_id in user_states:
                user_data = user_states[sender_id]

                # Check if the user has uploaded a document
                if sender_id in uploaded_documents:
                    # Clear the document from memory
                    del uploaded_documents[sender_id]
                    logger.info(f"Cleared uploaded document for {sender_id}.")

                # Set user as exited by updating the user state
                user_states[sender_id]['old_user_exited'] = True

            await self.api_connection.send_message(sender_id, "👋 You have successfully *Exited* the session. Thank You!")
            await self.send_list_message(sender_id=sender_id,VERSION=self.VERSION, ACCESS_TOKEN=self.ACCESS_TOKEN, PHONE_NUMBER_ID=self.PHONE_NUMBER_ID)
        except Exception as e:
            logger.error(f"Error occurred while handling exit command: {str(e)}")