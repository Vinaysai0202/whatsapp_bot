import os
from app.buttons import BUTTONS
from shared.api_handler import APIHANDLER
import requests
import json
from typing import Dict, Any
import logging
logger = logging.getLogger()

user_states: Dict[str, Dict[str, Any]] = {}
uploaded_documents: Dict[str, bytes] = {}

class WHATSAPP:
    def __init__(self):
        self.ACCESS_TOKEN = os.getenv('ACCESS_TOKEN')
        self.PHONE_NUMBER_ID = os.getenv('PHONE_NUMBER_ID')
        self.VERSION = os.getenv
        self.VERIFY_TOKEN = os.getenv("VERIFY_TOKEN") 
        self.EXTERNAL_API_URL = os.getenv('EXTERNAL_API_URL')
        self.QUERY_API_URL = os.getenv('QUERY_API_URL')
        self.BUTTONS= BUTTONS()
        self.api_connection = APIHANDLER()
        self.container_mapping = {
            "print_media": ("print-media", "*Access to Digital Library Resource*"),  # Access to print media resources
            "digital_library": ("digital-library", "*Access to Digital Library Resource*"),  # Access to digital library materials
            "social_media": ("social-media", "*Engage with Social Media*"),  # Engage with social media content
            "district_news": ("news", "*Local News Articles*"),  # Local news and updates
            "government_orders": ("gos-library", "*Government Orders Resource*"),  # Government orders and regulations
            "file_upload": ("file-upload", "*Upload and Explore a File*"),  # Upload and manage files
            "global": ("global", "*Access to Global Resource*")  # Access to global resources
        }

    

    async def download_document(self,media_id):
        """
        Download the document from WhatsApp servers using the media ID.
        """
        logger.info("Download the document from WhatsApp servers using the media ID.")
        url = f"https://graph.facebook.com/{self.VERSION}/{media_id}"
        headers = {"Authorization": f"Bearer {self.ACCESS_TOKEN}"}
        response = requests.get(url, headers=headers)

        if response.status_code == 200:
            media_url = response.json().get('url')
            if media_url:
                response = requests.get(media_url, headers=headers)
                if response.status_code == 200:
                    return response.content
                else:
                    logger.error(f"Failed to download media: {response.text}")
            else:
                logger.error("Media URL not found in response.")
        else:
            logger.error(f"Failed to get media URL: {response.text}")
        return None

    
    
    # async def whatsapp_bot(self, data):
    async def whatsapp_bot(self, data):
        try:
            if 'entry' not in data:
                return {"status": "No entries found"}

            for entry in data['entry']:
                if 'changes' not in entry:
                    continue
                
                # Ensure 'changes' exist and process each change
                for change in entry['changes']:
                    if 'value' not in change:
                        continue
                    
                    if 'messages' not in change['value']:
                        continue
                    
                    # Iterate over the messages
                    for message in change['value']['messages']:
                        sender_id = message['from']  # Get the sender's WhatsApp ID
                        message_id = message['id']  # Get the message ID
                        message_body = message.get('text', {}).get('body', '')  # Get the message body

                        # Check if the message ID has already been processed
                        if message_id in user_states.get(sender_id, {}).get('processed_message_ids', set()):
                            logger.info(f"Message ID {message_id} has already been processed. Skipping.")
                            continue  # Skip processing this message

                        # Initialize processed message IDs for this sender
                        user_states.setdefault(sender_id, {}).setdefault('processed_message_ids', set()).add(message_id)

                        # If the user has exited previously, do not send the list message again
                        if user_states[sender_id].get('old_user_exited', False):
                            logger.info(f"User {sender_id} has exited previously. Not sending list message.")
                            continue  # Skip sending list message

                        # If the user is new or has not exited and greeted
                        if message_body.lower() in ['hi', 'hello','hii','hlo']:
                            await self.BUTTONS.send_list_message(sender_id=sender_id, VERSION=self.VERSION, ACCESS_TOKEN=self.ACCESS_TOKEN, PHONE_NUMBER_ID=self.PHONE_NUMBER_ID)  # Send list to new user
                            continue

                        # Initialize variables for user state and message
                        button_id = None
                        user_msg = None
                        docs_upload = False  # Initialize document upload state
                        just_uploaded_document = False  # Flag to track if a document was just uploaded
                        whatsapp_button = None  # Initialize whatsapp_button to ensure it has a default value
                        container_id = None
                        # Check if the message is a list reply (instead of button reply)
                        if 'interactive' in message:
                            if 'list_reply' in message['interactive']:
                                button_id = message['interactive']['list_reply']['id']  # Get the ID from list_reply
                                logger.info(f"List button clicked: {button_id} by {sender_id}")
                                
                                # Unpack the four values from handle_button_click
                                button_id, container_id, description, response_message = await self.BUTTONS.handle_button_click(
                                    button_id=button_id, 
                                    container_mapping=self.container_mapping,
                                    sender_id=sender_id
                                )

                                # Set whatsapp_button to the response message
                                if response_message:  # Ensure there's a message to send
                                    await self.api_connection.send_message(sender_id, response_message)
                                    user_states[sender_id]['container_id'] = container_id
                                    logger.info(f"Container ID: {container_id}, Description: {description}, Response: {response_message}")

                            elif 'button_reply' in message['interactive']:
                                button_id = message['interactive']['button_reply']['id']  # Get the ID from button_reply
                                logger.info(f"Button clicked: {button_id} by {sender_id}")
                                
                                # Unpack the four values from handle_button_click
                                button_id, container_id, description, response_message = await self.BUTTONS.handle_button_click(
                                    button_id=button_id, 
                                    container_mapping=self.container_mapping,
                                    sender_id=sender_id
                                )

                                # Set whatsapp_button to the response message
                                if response_message:  # Ensure there's a message to send
                                    await self.api_connection.send_message(sender_id, response_message)
                                    user_states[sender_id]['container_id'] = container_id
                                    logger.info(f"Container ID: {container_id}, Description: {description}, Response: {response_message}")

                            else:
                                logger.warning(f"Unknown interactive type from {sender_id}: {message['interactive']}")
                                continue  # Skip unknown types


                            # Additional handling to ensure whatsapp_button is correctly assigned
                            if whatsapp_button:
                                # Send whatsapp_button response back to user or continue processing
                                logger.info(f"whatsapp_button assigned for {sender_id}: {whatsapp_button}")
                            else:
                                logger.warning(f"No valid whatsapp_button assigned for {sender_id}")

                        
                            # Later in the code when processing the message
                            current_container_name = user_states[sender_id].get('container_id', "default_container")
                            logger.info(f"Current container for {sender_id}: {current_container_name}")  # Add this log for debugging


                        # Handle text message
                        try:
                            if 'text' in message:
                                user_msg = message['text']['body']
                                logger.info(f"Received text message from {sender_id}: {user_msg}")

                                # Check if the last message is the same as the current one
                                # if user_states[sender_id].get('last_message') == user_msg:
                                #     logger.info(f"Duplicate message from {sender_id}: {user_msg}. Skipping.")
                                #     continue  # Skip this message if it's the same as the last one

                                # Check if the user pressed "exit"
                                if user_msg.lower() == 'exit':
                                    logger.info(f"Exit option selected by {sender_id}.")
                                    await self.BUTTONS.handle_exit(sender_id)
                                    user_states.pop(sender_id, None)  # Clear user state
                                    return {"status": "User exited"}

                                # If a document has been uploaded, handle the query
                                if sender_id in user_states and 'file_name' in user_states[sender_id]:
                                    # Only process query if a document was not just uploaded
                                    if not just_uploaded_document:
                                        logger.info(f"User message after document upload: {user_msg}")
                                        await self.api_connection.send_message(sender_id, "*Data* is retrieving, ⏳ Please hold a moment")
                                        logger.info(f"Type of user_states: {type(user_states)}")
                                        
                                        # Attempt to process the document
                                        try:
                                            logger.info("Preparing to forward document to external API.")
                                            
                                            # Retrieve the uploaded document for the sender
                                            uploaded_file = uploaded_documents.get(sender_id)
                                            if uploaded_file is None:
                                                raise ValueError(f"No uploaded document found for user: {sender_id}")
                                            
                                            # logger.info(f"Type of user_states: {type(user_states)}")
                                            # logger.info(f"sender_id: {sender_id},  uploaded_file: {uploaded_file}, text: {user_msg}")
                                            
                                            # Call the function to forward the document to the external API
                                            response = await self.api_connection.forward_document_to_external_api(
                                                sender_id=sender_id,                    # Pass the sender_id
                                                user_states=user_states,                # Pass the user_states dictionary
                                                uploaded_file=uploaded_file,            # Pass the actual uploaded file data
                                                text=user_msg                           # Pass the user message as text
                                            )
                                            
                                            logger.info(f"API response: {response}")
                                            await self.api_connection.send_message(sender_id, response)
                                            user_states[sender_id]['last_message'] = user_msg  # Store last message

                                            # Send exit button after API response
                                            await self.BUTTONS.send_message_with_exit_button(
                                                recipient_waid=sender_id, 
                                                message="If you have any further questions, please feel free to ask. Otherwise, you may select 🔘 'Exit' to conclude this session.", 
                                               
                                            )
                                        except Exception as e:
                                            logger.error(f"Error while processing the document for user {sender_id}: {e}")
                                            await self.api_connection.send_message(sender_id, "There was an error processing your request. Please try again later.")
                                    else:
                                        logger.info(f"Query ignored for {sender_id} immediately after document upload.")
                                else:
                                    # Call QUERY_API_URL for normal user queries if whatsapp_button is not None
                                    await self.api_connection.send_message(sender_id, "*Data* is retrieving, ⏳ Please hold a moment")
                                    # Check if the user already selected a container; otherwise, default
                                    if sender_id in user_states and 'container_id' in user_states[sender_id]:
                                        current_container_name = user_states[sender_id]['container_id']
                                    else:
                                        current_container_name = "default_container"

                                    response = await self.api_connection.query_external_api(
                                        message=user_msg, current_container_name=current_container_name
                                    )
                                    logger.info(f"API response: {response}")
                                    await self.api_connection.send_message(sender_id, response)
                                    user_states[sender_id]['last_message'] = user_msg  # Store last message

                                    # Send exit button after API response
                                    await self.BUTTONS.send_message_with_exit_button(recipient_waid=sender_id, message="If you have any further questions, please feel free to ask. Otherwise, you may select 🔘 'Exit' to conclude this session.")
                        except Exception as e:
                            await self.BUTTONS.send_message_with_exit_button(recipient_waid=sender_id, message="If you have any further questions, please feel free to ask. Otherwise, you may select 🔘 'Exit' to conclude this session.")
                            logger.error(f"Error processing text message for {sender_id}: {e}")
  

                        # Handle document upload
                        try:
                            if 'document' in message:
                                media_id = message['document']['id']
                                file_name = message['document'].get('filename', 'No filename')

                                # Download and store the document in memory
                                acknowledgment_message = "⚖️ Thank you for your *Submission*. Your document is currently under *Review*. Please hold on for a few moments."
                                await self.api_connection.send_message(sender_id, acknowledgment_message) 
                                file_data = await self.download_document(media_id=media_id)

                                # Store the file in memory
                                uploaded_documents[sender_id] = file_data

                                logger.info(f"Stored document for {sender_id}: {file_name}, Size: {len(file_data)} bytes")
                                await self.api_connection.send_message(sender_id, "📥 The document has been *Successfully Reviewed*. I'm now available to assist you with any questions regarding its content.")

                                # Update user state
                                user_states[sender_id]['file_name'] = file_name
                                print(user_states)
                                just_uploaded_document = True  # Set the flag to true
                                continue  # Move to the next message

                        except Exception as e:
                            logger.error(f"Error handling document upload for {sender_id}: {e}")
        except Exception as e:
            logger.error(f"Error in the main : {str(e)}")