from pydantic import BaseModel

class WhatsAppResponse(BaseModel):
    recipient_waid: str
    message: str