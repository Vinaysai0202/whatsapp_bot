import os
import json
import requests
from bs4 import BeautifulSoup
import logging
import time
logger = logging.getLogger()

class APIHANDLER():
    def __init__(self):
        self.ACCESS_TOKEN = os.getenv('ACCESS_TOKEN')
        self.PHONE_NUMBER_ID = os.getenv('PHONE_NUMBER_ID')
        self.VERSION = os.getenv
        self.VERIFY_TOKEN = os.getenv("VERIFY_TOKEN") 
        self.EXTERNAL_API_URL = os.getenv('EXTERNAL_API_URL')
        self.QUERY_API_URL = os.getenv('QUERY_API_URL') 
        
    async def forward_document_to_external_api(self, sender_id: str, user_states: dict, uploaded_file, text=None):
        """
        Forward the appropriate document to the external API based on the user's context and return the response.
        """
        logger.info("Starting to forward document to the external API.")

        try:
            if not uploaded_file:
                logger.warning(f"No document available for processing for user: {sender_id}.")
                return "No document available for processing."

            filename = user_states[sender_id]['file_name']
            url = self.EXTERNAL_API_URL

            files = {'file': (filename, uploaded_file, 'application/octet-stream')}
            data = {
                "containerName": "file-upload",
                "subject": text or "summarize"
            }

            logger.info(f"Payload sending to API ---> {data}")

            MAX_RETRIES = 3
            for attempt in range(MAX_RETRIES):
                try:
                    response = requests.post(url, data=data, files=files, timeout=30)
                    if response.status_code == 200:
                        api_response = response.json()
                        html_content = api_response.get('response', {}).get('narration', [])
                        if html_content:
                            soup = BeautifulSoup(html_content[0], "html.parser")
                            return soup.get_text(separator="\n")[:4800]
                        else:
                            logger.warning(f"No narration found in the API response for user: {sender_id}.")
                            return "No narration found in the API response."
                    else:
                        logger.error(f"Failed to process document, status code: {response.status_code} for user: {sender_id}.")
                        return f"Failed to process document, status code: {response.status_code}"
                except requests.exceptions.Timeout:
                    logger.warning(f"Attempt {attempt + 1} timed out, retrying...")
                    time.sleep(2)  # Wait before retrying
            return "Failed to process document after multiple attempts."
        
        except Exception as e:
            logger.error(f"Error forwarding document to API for {sender_id}: {str(e)}")
            return f"Error forwarding document to API: {str(e)}"

        
    async def query_external_api(self, message: str, current_container_name: str):
        """
        Query the external API using the current container name and message.
        """
        logger.info("Query the external API using the current container name and message.")
        
        if current_container_name is None:
            return "Please select a department before asking questions."

        # Form data for the API request
        form_data = {
            "containerName": current_container_name,  # Use the current container name
            "subject": message
        }

        if current_container_name in ["social-media", "news"]:
            form_data["fromDate"] = "2024-09-01"  # Fixed fromDate
            form_data["toDate"] = "2024-10-22"    # Fixed toDate

        # Log form data
        logger.info(f"Form data being sent: {form_data}")

        try:
            # Send the request to the external API
            response = requests.post(self.QUERY_API_URL, data=form_data)

            if response.status_code == 200:
                api_response = response.json()
                narration = api_response.get('response', {}).get('narration', [])
                if narration:
                    soup = BeautifulSoup(narration[0], "html.parser")
                    return soup.get_text()[:4800]
                else:
                    return "Oops! We couldn’t find any results for your query. 😔"
            else:
                logger.error(f"Error response from API: {response.text}")
                return f"Failed to retrieve a response, status code: {response.status_code}"

        except Exception as e:
            logger.error(f"Error querying external API: {str(e)}")
            return f"Error querying external API: {str(e)}"
        
    async def send_whatsapp_message(self, recipient_waid: str, message: str):
        try:
            url = f"https://graph.facebook.com/{os.getenv('VERSION')}/{os.getenv('PHONE_NUMBER_ID')}/messages"
            headers = {
                "Authorization": f"Bearer {os.getenv('ACCESS_TOKEN')}",
                "Content-Type": "application/json",
            }

            data = {
                "messaging_product": "whatsapp",
                "to": recipient_waid,
                "type": "text",
                "text": {
                    "body": message
                }
            }

            response = requests.post(url, headers=headers, json=data)
            logger.info(f"WhatsApp API Response: {response.status_code} {response.text}")

            if response.status_code == 200:
                return {"status": "Message sent successfully"}
            else:
                return {"status": "Failed to send message", "error": response.text}
            
        except Exception as e:
            logger.error(f"Error sending WhatsApp message: {str(e)}")
            return {"status": "Failed to send message", "error": str(e)}
        
    async def send_message(self,recipient_waid:str, message:str):
        """
        Send an automatic reply using the WhatsApp Business API.
        """
        logger.info("Send an automatic reply using the WhatsApp Business API.")
        logger.info(f"Preparing to send auto-reply to {recipient_waid}. Message: {message}")

        try:
            url = f"https://graph.facebook.com/{self.VERSION}/{self.PHONE_NUMBER_ID}/messages"
            headers = {
                "Authorization": f"Bearer {self.ACCESS_TOKEN}",
                "Content-Type": "application/json",
            }

            # Convert the message to a string if it's a dictionary
            if isinstance(message, dict):
                message = json.dumps(message, indent=2)

            data = {
                "messaging_product": "whatsapp",
                "to": recipient_waid,
                "type": "text",
                "text": {
                    "body": message
                }
            }

            response = requests.post(url, headers=headers, json=data)

            if response.status_code != 200:
                logger.error(f"Failed to send auto-reply: {response.text}")
        except Exception as e:
            logger.error(f"Error occurred while sending auto-reply: {str(e)}")